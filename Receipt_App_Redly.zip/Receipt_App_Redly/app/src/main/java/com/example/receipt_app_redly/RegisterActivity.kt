package com.example.receipt_app_redly // 1. 자신의 실제 패키지명인지 확인 필수!

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton

class RegisterActivity : AppCompatActivity() {

    // 변수 선언
    private lateinit var imageView: ImageView
    private lateinit var photoHint: TextView
    private var selectedBitmap: Bitmap? = null

    // 카메라 실행 결과 처리
    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val bitmap = result.data?.extras?.get("data") as? Bitmap
            bitmap?.let { updatePreview(it) }
        }
    }

    // 갤러리 실행 결과 처리
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data
            uri?.let {
                val bitmap = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val source = ImageDecoder.createSource(contentResolver, it)
                    ImageDecoder.decodeBitmap(source)
                } else {
                    @Suppress("DEPRECATION")
                    MediaStore.Images.Media.getBitmap(contentResolver, it)
                }
                updatePreview(bitmap)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        // 2. XML ID 연결 (Unresolved reference 해결 지점)
        imageView = findViewById(R.id.imageView)
        photoHint = findViewById(R.id.photoHint)
        val btnCamera = findViewById<Button>(R.id.btnCamera)
        val btnGallery = findViewById<Button>(R.id.btnGallery)
        val fabSave = findViewById<FloatingActionButton>(R.id.fab)

        // 카메라 클릭
        btnCamera.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            cameraLauncher.launch(intent)
        }

        // 갤러리 클릭
        btnGallery.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            galleryLauncher.launch(intent)
        }

        // 저장 버튼(FAB) 클릭 시 이동
        fabSave.setOnClickListener {
            if (selectedBitmap != null) {
                DataBridge.tempBitmap = selectedBitmap
                val intent = Intent(this, DetailInputActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "먼저 사진을 등록해주세요!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updatePreview(bitmap: Bitmap) {
        selectedBitmap = bitmap
        imageView.setImageBitmap(bitmap)
        photoHint.visibility = View.GONE
    }
}