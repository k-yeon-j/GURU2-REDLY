package com.example.receipt_app_redly

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        // 1. Intent에서 카테고리 정보 가져오기
        val categoryId = intent.getIntExtra("CATEGORY_ID", -1)
        val categoryName = intent.getStringExtra("CATEGORY_NAME") ?: "목록"

        // 2. XML 뷰 연결
        val tvTitle = findViewById<TextView>(R.id.tvTitle)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerViewList)

        // 3. 상단 제목 설정
        tvTitle.text = "$categoryName 내역"

        // 4. 리사이클러뷰 레이아웃 매니저 설정
        recyclerView.layoutManager = LinearLayoutManager(this)

        // 5. DB에서 해당 카테고리의 영수증 리스트 가져오기
        val db = DBHelper(this)
        // [참고] DBHelper의 getReceiptsByCategory는 내부에서 이미 Bitmap 변환을 마친 상태여야 함
        val receiptList = db.getReceiptsByCategory(categoryId)

        // 6. 어댑터 연결 (수정된 ReceiptListAdapter 사용)
        recyclerView.adapter = ReceiptListAdapter(receiptList)
    }
}