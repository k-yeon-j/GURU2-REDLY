package com.example.receipt_app_redly

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context) : SQLiteOpenHelper(context, "guru2DB", null, 4) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE user (ID TEXT PRIMARY KEY, PW TEXT);")
        db.execSQL("CREATE TABLE categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, emoji TEXT)")
        // image 타입을 TEXT로 설정하여 파일 경로를 저장합니다.
        db.execSQL("CREATE TABLE receipts (id INTEGER PRIMARY KEY AUTOINCREMENT, image TEXT, memo TEXT, category_id INTEGER, date LONG)")
        insertDefaultCategories(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS user")
        db.execSQL("DROP TABLE IF EXISTS categories")
        db.execSQL("DROP TABLE IF EXISTS receipts")
        onCreate(db)
    }

    private fun insertDefaultCategories(db: SQLiteDatabase) {
        val categories = arrayOf(
            arrayOf("식비", "🍚"), arrayOf("카페", "☕"), arrayOf("마트", "🛒"), arrayOf("술", "🍺"),
            arrayOf("쇼핑", "🛍️"), arrayOf("취미", "🎮"), arrayOf("의료", "🏥"), arrayOf("주거", "🏠"),
            arrayOf("금융", "📑"), arrayOf("미용", "💄"), arrayOf("교통", "🚗"), arrayOf("여행", "✈️"),
            arrayOf("교육", "🎓"), arrayOf("생활", "🧺"), arrayOf("기부", "💖"), arrayOf("기타", "💬")
        )
        for (cat in categories) {
            val values = ContentValues().apply {
                put("name", cat[0]); put("emoji", cat[1])
            }
            db.insert("categories", null, values)
        }
    }

    fun signup(id: String, pw: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply { put("ID", id); put("PW", pw) }
        return db.insert("user", null, values) != -1L
    }

    fun login(id: String, pw: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM user WHERE ID=? AND PW=?", arrayOf(id, pw))
        val exists = cursor.moveToFirst()
        cursor.close()
        return exists
    }

    // [추가된 함수] 카테고리 전체 목록을 불러옵니다. 이 함수가 없어서 에러가 났었습니다.
    fun getAllCategories(): List<Map<String, Any>> {
        val list = mutableListOf<Map<String, Any>>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM categories", null)
        if (cursor.moveToFirst()) {
            do {
                val map = mutableMapOf<String, Any>()
                map["id"] = cursor.getInt(0)
                map["name"] = cursor.getString(1)
                map["emoji"] = cursor.getString(2)
                list.add(map)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }

    // 사진 파일의 경로(imagePath)를 저장합니다.
    fun insertReceipt(categoryId: Int, date: Long, memo: String, imagePath: String?): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("category_id", categoryId)
            put("date", date)
            put("memo", memo)
            put("image", imagePath)
        }
        return db.insert("receipts", null, values)
    }

    fun getReceiptsByCategory(categoryId: Int): List<Map<String, Any?>> {
        val list = mutableListOf<Map<String, Any?>>()
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT * FROM receipts WHERE category_id = ? ORDER BY date DESC", arrayOf(categoryId.toString()))

        if (cursor.moveToFirst()) {
            do {
                val map = mutableMapOf<String, Any?>()
                map["id"] = cursor.getInt(0)
                map["imagePath"] = cursor.getString(1) // 경로 텍스트
                map["memo"] = cursor.getString(2)
                map["date"] = cursor.getLong(4)
                list.add(map)
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }
}