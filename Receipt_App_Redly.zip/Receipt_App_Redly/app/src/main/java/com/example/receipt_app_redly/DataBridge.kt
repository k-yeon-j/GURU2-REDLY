package com.example.receipt_app_redly
import android.graphics.Bitmap

object DataBridge {
    var tempBitmap: Bitmap? = null
}