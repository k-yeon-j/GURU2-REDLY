package com.example.receipt_app_redly

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.textfield.TextInputEditText
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class DetailInputActivity : AppCompatActivity() {
    private var selectedCategoryId: Int? = null
    private var selectedDateMillis: Long? = null
    private lateinit var textRecognizer: com.google.mlkit.vision.text.TextRecognizer

    // [해결] 클래스 레벨에서 db 변수를 선언합니다.
    private lateinit var db: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // [해결] R 관련 에러 방지를 위해 패키지명을 포함한 전체 경로를 사용합니다.
        setContentView(com.example.receipt_app_redly.R.layout.activity_detail_input)

        // [해결] db 변수를 여기서 초기화합니다.
        db = DBHelper(this)
        textRecognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())

        // 뷰 연결
        val imageView = findViewById<ImageView>(com.example.receipt_app_redly.R.id.imagePreview)
        val editDate = findViewById<TextInputEditText>(com.example.receipt_app_redly.R.id.editDate)
        val editMemo = findViewById<TextInputEditText>(com.example.receipt_app_redly.R.id.editMemo)
        val categoryGroup = findViewById<MaterialButtonToggleGroup>(com.example.receipt_app_redly.R.id.groupCategory)
        val btnOcr = findViewById<Button>(com.example.receipt_app_redly.R.id.btnOcr)
        val btnSave = findViewById<Button>(com.example.receipt_app_redly.R.id.btnSave)

        // 메모장 내부 스크롤 가로채기 방지 적용
        setupMemoInnerScroll(editMemo)

        DataBridge.tempBitmap?.let {
            imageView.setImageBitmap(it)
        }

        // [해결] 'db.getAllCategories()'로 호출하여 참조 에러를 해결합니다.
        setupCategoryButtons(categoryGroup, db.getAllCategories())

        // 날짜 선택 설정
        val datePicker = MaterialDatePicker.Builder.datePicker().setTitleText("날짜 선택").build()
        editDate.setOnClickListener {
            if (!datePicker.isAdded) {
                datePicker.show(supportFragmentManager, "MATERIAL_DATE_PICKER")
            }
        }
        datePicker.addOnPositiveButtonClickListener {
            selectedDateMillis = it
            editDate.setText(SimpleDateFormat("yyyy.MM.dd", Locale.getDefault()).format(Date(it)))
        }

        // OCR 인식 버튼 로직
        btnOcr.setOnClickListener {
            DataBridge.tempBitmap?.let { bitmap ->
                btnOcr.isEnabled = false
                btnOcr.text = "인식 중…"

                val input = InputImage.fromBitmap(bitmap, 0)
                textRecognizer.process(input)
                    .addOnSuccessListener { result ->
                        val recognized = result.text.trim()
                        if (recognized.isNotBlank()) {
                            val currentText = editMemo.text.toString()
                            val newText = if (currentText.isEmpty()) recognized else "$currentText\n$recognized"
                            editMemo.setText(newText)
                        }
                    }
                    .addOnCompleteListener {
                        btnOcr.isEnabled = true
                        btnOcr.text = "OCR로 텍스트 추출"
                    }
            }
        }

        // 저장 버튼 로직 (이미지 경로 저장 방식)
        btnSave.setOnClickListener {
            val memoText = editMemo.text.toString()

            if (selectedCategoryId != null && selectedDateMillis != null) {
                var imagePath: String? = null

                try {
                    DataBridge.tempBitmap?.let { bitmap ->
                        val fileName = "receipt_${System.currentTimeMillis()}.jpg"
                        val file = File(filesDir, fileName)
                        val out = FileOutputStream(file)
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                        out.close()
                        imagePath = file.absolutePath
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                // DB 저장 (이미지 자체가 아닌 경로 String 전달)
                val result = db.insertReceipt(
                    selectedCategoryId!!,
                    selectedDateMillis!!,
                    memoText,
                    imagePath
                )

                if (result != -1L) {
                    Toast.makeText(this, "저장되었습니다!", Toast.LENGTH_SHORT).show()
                    DataBridge.tempBitmap = null
                    val intent = Intent(this, HomeActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    startActivity(intent)
                    finish()
                }
            } else {
                Toast.makeText(this, "날짜와 카테고리를 선택해주세요.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // [핵심] 메모장 내부 스크롤 처리 함수
    private fun setupMemoInnerScroll(edit: TextInputEditText) {
        edit.setOnTouchListener { v, event ->
            if (v.hasFocus()) {
                // 부모 스크롤뷰가 이 터치를 가로채지 못하게 설정함
                v.parent.requestDisallowInterceptTouchEvent(true)
                if (event.action == MotionEvent.ACTION_UP || event.action == MotionEvent.ACTION_CANCEL) {
                    v.parent.requestDisallowInterceptTouchEvent(false)
                }
            }
            false
        }
    }

    private fun setupCategoryButtons(group: MaterialButtonToggleGroup, categories: List<Map<String, Any>>) {
        group.removeAllViews()
        categories.forEach { cat ->
            val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = "${cat["emoji"]} ${cat["name"]}"
                isCheckable = true
                this.id = View.generateViewId()
                tag = cat["id"] as Int
            }
            group.addView(btn)
        }
        group.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                val checkedButton = group.findViewById<MaterialButton>(checkedId)
                selectedCategoryId = checkedButton.tag as Int
            }
        }
    }
}