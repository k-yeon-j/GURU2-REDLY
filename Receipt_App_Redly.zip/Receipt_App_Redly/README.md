# GURU2-REDLY
25년 겨울학기 GURU2 22조 팀 '레들리'입니다.
